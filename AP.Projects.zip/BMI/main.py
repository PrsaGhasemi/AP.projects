from window import Window

if __name__ == '__main__':
    window = Window('BMI Calculator', 400, 250)
    window.run()

