from elevator import BasicElevator
from elevator_gui import timesteps

elevator = BasicElevator(1,10)
timesteps(50, elevator)