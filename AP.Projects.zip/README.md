# AP.projects
here i upload my AdvancedProgramming projects so it'd be easier to have access to them
Built by 
Farimah Fotuhi Fard 992011052
Parsa Ghaseemi 992011053
we created these projects together and with the help of many many internet websites and other github repositories BUT we didnt COPY_PASTE anything from anywhere. we read,understood and re-created our own projects.
here also u'll have a summary about each question. hope you'll enjoy our work:

q1: it is a simple BMI calculator created with python and also has a basic interface using tkinter, the interesting part about it is that this calculator is able to convert different kinds of standars such as pound and inch into us standards! 

q2: in this project our main goal is to create an algorithm to find a route so we take the shortest route among floors with an equal distance among them. in this question every passenger (as if we created the OOP class with) has an entering floor and a destination floor, with a keyboard on every floor (according to the question) we know every passengers a,b points! so with all these information we need to find a way for the elevator to help all passengers with the least possible moves. 
p.s: for this question we didnt make a input list for passengers so we could create a beautiful(as we hope!) gui for it

q3: its just a simple 3d vectors calculator! u can change the incoming data from the main.py vec1 and vec2 parameters (cuz there wasn't a gui needed in the question)

q4: this question is like a math formula written with python codes, the question tells us about 3 different kinds of mortgages and ways to calculate them. for this question we have many variables like loan amount, monthly interest rate, duration of the loan in months and total pay months! in other words u have monthly rate(r) months(m) and loan amount(loan) and then with the given formulas you determine wanted variables and in show you with each rate, how much money in how many months will be paid by the customer

q5: this is enigma machine built with python, for further description, watch "The Imitation Game" movie